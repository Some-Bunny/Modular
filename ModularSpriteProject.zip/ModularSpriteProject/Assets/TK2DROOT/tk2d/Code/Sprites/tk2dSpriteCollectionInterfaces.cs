namespace tk2dRuntime
{
	public interface ISpriteCollectionForceBuild
	{
		bool UsesSpriteCollection(tk2dSpriteCollectionData spriteCollection);
		void ForceBuild();
	}
}
