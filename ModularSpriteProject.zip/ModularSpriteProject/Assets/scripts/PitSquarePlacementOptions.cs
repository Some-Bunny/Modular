﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PitSquarePlacementOptions {

	public float PitSquareChance;

	// Token: 0x04004CC6 RID: 19654
	public bool CanBeFlushLeft;

	// Token: 0x04004CC7 RID: 19655
	public bool CanBeFlushRight;

	// Token: 0x04004CC8 RID: 19656
	public bool CanBeFlushBottom;
}
