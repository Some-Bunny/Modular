﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileIndexList {

	[SerializeField]
	public List<int> indices;

	// Token: 0x04004CCA RID: 19658
	[SerializeField]
	public List<float> indexWeights;
}
